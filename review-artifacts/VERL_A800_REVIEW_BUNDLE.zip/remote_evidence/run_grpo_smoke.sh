#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/verl-a800
/root/venvs/verl-a800/bin/python "$root/scripts/run_grpo.py" --root "$root" --name smoke_on_nested_3 --steps 3 --save-freq -1 --lazy --timeout-seconds 1200
