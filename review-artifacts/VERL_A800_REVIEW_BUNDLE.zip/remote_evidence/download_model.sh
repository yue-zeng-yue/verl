#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/verl-a800
test -x /root/venvs/hf-tools/bin/python || /root/miniconda3/bin/uv venv /root/venvs/hf-tools --python /root/miniconda3/bin/python
/root/miniconda3/bin/uv pip install --python /root/venvs/hf-tools/bin/python --index-url https://mirrors.aliyun.com/pypi/simple 'huggingface-hub==1.30.0'
HF_ENDPOINT=https://hf-mirror.com HF_HUB_DISABLE_XET=1 /root/venvs/hf-tools/bin/hf download Qwen/Qwen2.5-1.5B-Instruct --revision 989aa7980e4cf806f80c7fef2b1adb7bc71aa306 --local-dir "$root/model" --include '*.safetensors' --include '*.json' --include '*.txt' --include '*.jinja' --max-workers 2
printf '{"status":"complete","revision":"989aa7980e4cf806f80c7fef2b1adb7bc71aa306","endpoint":"https://hf-mirror.com"}\n' > "$root/model_download.json"
