#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/verl-a800
bash "$root/run_distributed.sh" > "$root/logs/distributed_unit_nested.log" 2>&1
timeout --kill-after=15 90 /root/venvs/verl-a800/bin/ray stop --force > "$root/logs/smoke_ray_cleanup.log" 2>&1
bash "$root/run_grpo_smoke.sh" > "$root/logs/grpo_smoke_nested_driver.log" 2>&1
printf '{"status":"pass"}\n' > "$root/gpu_stage_exit.json"
