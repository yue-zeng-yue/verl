#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/verl-a800
export PATH=/root/venvs/verl-a800/bin:$PATH
export PYTHONPATH="$root/source" VERL_USE_EXTERNAL_PLUGINS=none VERL_DISABLE_FLASH_ATTN_CE=1
export OMP_NUM_THREADS=4 TOKENIZERS_PARALLELISM=false CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "$root/source"
python "$root/preflight.py" > "$root/logs/preflight.log" 2>&1
/root/miniconda3/bin/uv pip check --python /root/venvs/verl-a800/bin/python > "$root/logs/pip_check_final.txt" 2>&1
python -m pytest tests/workers/config/test_engine_config_on_cpu.py tests/workers/test_fsdp_optimizer_offload_step_on_cpu.py tests/workers/test_fsdp_gradient_accumulation_sync_on_cpu.py tests/workers/test_fsdp_temperature_scaling_on_cpu.py tests/workers/test_engine_forward_step_detach_on_cpu.py tests/workers/test_engine_return_model_output_on_cpu.py -q > "$root/logs/cpu_regressions.log" 2>&1
timeout --kill-after=30 300 torchrun --standalone --nproc-per-node=2 tests/special_distributed/test_fsdp2_optimizer_offload_step.py > "$root/logs/distributed_unit.log" 2>&1
printf '{"status":"pass"}\n' > "$root/checks_exit.json"
