#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/verl-a800
export PATH=/root/venvs/verl-a800/bin:$PATH
export OMP_NUM_THREADS=4 TOKENIZERS_PARALLELISM=false CUBLAS_WORKSPACE_CONFIG=:4096:8
export VERL_USE_EXTERNAL_PLUGINS=none VERL_DISABLE_FLASH_ATTN_CE=1
for case_name in upstream off on; do
  source_path="$root/source"
  args=()
  if [ "$case_name" = upstream ]; then source_path="$root/source_upstream"; fi
  if [ "$case_name" = on ]; then args+=(--lazy); fi
  CUDA_VISIBLE_DEVICES=0 PYTHONPATH="$source_path" timeout --kill-after=30 900 torchrun --standalone --nproc-per-node=1 "$root/scripts/fixed_input.py" --model "$root/model" --out "$root/fixed/single_$case_name" --seq 128 --steps 6 --outer-context --deterministic "${args[@]}" > "$root/logs/fixed_single_$case_name.log" 2>&1
done
for case_name in off on; do
  args=()
  if [ "$case_name" = on ]; then args+=(--lazy); fi
  PYTHONPATH="$root/source" timeout --kill-after=30 900 torchrun --standalone --nproc-per-node=2 "$root/scripts/fixed_input.py" --model "$root/model" --out "$root/fixed/dual_$case_name" --seq 128 --steps 6 --outer-context --deterministic "${args[@]}" > "$root/logs/fixed_dual_$case_name.log" 2>&1
done
python - <<'PY'
from pathlib import Path
import json
root=Path('/root/autodl-tmp/verl-a800/fixed')
def read(arm,rank):
 return json.loads((root/arm/f'rank_{rank}/final_fingerprint.json').read_text())
assert read('single_upstream',0)==read('single_off',0)==read('single_on',0)
for rank in range(2):
 assert read('dual_off',rank)==read('dual_on',rank)
(root/'validation.json').write_text(json.dumps({'status':'PASS','single_upstream_off_on_full_fingerprints_equal':True,'dual_all_ranks_off_on_full_fingerprints_equal':True,'updates_per_run':6},indent=2))
print('FIXED_MATRIX_PASS',flush=True)
PY
