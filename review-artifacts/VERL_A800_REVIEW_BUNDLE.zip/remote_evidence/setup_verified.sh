#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/verl-a800
export UV_CACHE_DIR="$root/uv-cache" UV_PROJECT_ENVIRONMENT=/root/venvs/verl-a800
export UV_HTTP_TIMEOUT=120 UV_DEFAULT_INDEX=https://mirrors.aliyun.com/pypi/simple
export UV_CONCURRENT_DOWNLOADS=12
cd "$root/source"
/root/miniconda3/bin/uv sync --frozen --extra fsdp --extra vllm --no-install-package flash-attn --no-install-package torch --no-install-package torchvision --no-install-package torchaudio --python /root/miniconda3/bin/python
/root/miniconda3/bin/uv pip install --python /root/venvs/verl-a800/bin/python --no-deps "$root"/wheels/*.whl
/root/miniconda3/bin/uv pip check --python /root/venvs/verl-a800/bin/python > "$root/logs/pip_check.txt" 2>&1 || true
/root/venvs/verl-a800/bin/python -c 'import torch,vllm,transformers; print(torch.__version__,vllm.__version__,transformers.__version__,torch.cuda.device_count())'
printf '{"exit_code":0,"optional_flash_attention_pending":false,"attention":"sdpa"}\n' > "$root/setup_verified_exit.json"
