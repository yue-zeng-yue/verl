#!/usr/bin/env bash
set -euo pipefail
root=/root/autodl-tmp/verl-a800
export PATH=/root/venvs/verl-a800/bin:$PATH
export PYTHONPATH="$root/source" VERL_USE_EXTERNAL_PLUGINS=none VERL_DISABLE_FLASH_ATTN_CE=1
export OMP_NUM_THREADS=4 CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "$root/source"
timeout --kill-after=30 300 torchrun --standalone --nproc-per-node=2 tests/special_distributed/test_fsdp2_optimizer_offload_step.py
printf '{"status":"pass"}\n' > "$root/distributed_exit.json"
