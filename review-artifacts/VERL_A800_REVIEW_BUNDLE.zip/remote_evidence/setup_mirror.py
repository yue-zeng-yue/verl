from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('/root/autodl-tmp/verl-a800')
lock = root/'source/uv.lock'
original = lock.read_bytes()
(root/'uv.lock.upstream').write_bytes(original)
updated = original.replace(b'https://files.pythonhosted.org/', b'https://pypi.tuna.tsinghua.edu.cn/')
lock.write_bytes(updated)
(root/'install_provenance.json').write_text(json.dumps({
    'upstream_sha':'c80729fbdfdd3fc46a5b224a23cb04aab8f5e51d',
    'change':'Download host only: files.pythonhosted.org to pypi.tuna.tsinghua.edu.cn; versions and artifact SHA256 unchanged',
    'original_lock_sha256':hashlib.sha256(original).hexdigest(),
    'install_lock_sha256':hashlib.sha256(updated).hexdigest(),
}, indent=2))
env=dict(os.environ, UV_PROJECT_ENVIRONMENT='/root/venvs/verl-a800',
    UV_CACHE_DIR=str(root/'uv-cache'), UV_HTTP_TIMEOUT='120', UV_CONCURRENT_DOWNLOADS='12',
    UV_DEFAULT_INDEX='https://pypi.tuna.tsinghua.edu.cn/simple', UV_CONCURRENT_INSTALLS='2')
with (root/'logs/setup_mirror.log').open('w') as log:
    result=subprocess.run(['/root/miniconda3/bin/uv','sync','--frozen','--extra','fsdp','--extra','vllm',
        '--python','/root/miniconda3/bin/python'],cwd=root/'source',env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'setup_exit.json').write_text(json.dumps({'exit_code':result.returncode}))
