"""Final-source long-input check, enabled first to reverse execution order."""
from pathlib import Path
import json
import os
import subprocess
import time

root = Path('/root/autodl-tmp/verl-a800')
python = '/root/venvs/verl-a800/bin/python'
with (root/'logs/long_pair_ray_cleanup.log').open('w') as log:
    subprocess.run(['/root/venvs/verl-a800/bin/ray', 'stop', '--force'], stdout=log,
                   stderr=subprocess.STDOUT, timeout=90)
env = dict(os.environ, PYTHONPATH=str(root/'source'), VERL_USE_EXTERNAL_PLUGINS='none',
           VERL_DISABLE_FLASH_ATTN_CE='1', TOKENIZERS_PARALLELISM='false',
           CUBLAS_WORKSPACE_CONFIG=':4096:8', OMP_NUM_THREADS='8')
runs = []
cases = [('repeat128_on', True, 128, 6), ('repeat128_off', False, 128, 6),
         ('long8192_on', True, 8192, 2), ('long8192_off', False, 8192, 2)]
for name, enabled, sequence_length, updates in cases:
    output = root/'fixed'/name
    assert not output.exists(), output
    command = [python, '-m', 'torch.distributed.run', '--standalone', '--nproc-per-node=2',
               str(root/'scripts/fixed_input.py'), '--model', str(root/'model'),
               '--out', str(output), '--seq', str(sequence_length), '--steps', str(updates),
               '--outer-context', '--deterministic'] + (['--lazy'] if enabled else [])
    started = time.time()
    with (root/'logs'/f'{name}.log').open('w') as log:
        completed = subprocess.run(['timeout', '--kill-after=30s', '600s', *command],
                                   env=env, stdout=log, stderr=subprocess.STDOUT)
    runs.append(dict(name=name, command=command, start=started, end=time.time(),
                     exit_code=completed.returncode))
    (root/'fixed/long_pair_runs.json').write_text(json.dumps(runs, indent=2))
    assert completed.returncode == 0, runs[-1]
for prefix in ('repeat128', 'long8192'):
    for rank in (0, 1):
        a = json.loads((root/f'fixed/{prefix}_on/rank_{rank}/final_fingerprint.json').read_text())
        b = json.loads((root/f'fixed/{prefix}_off/rank_{rank}/final_fingerprint.json').read_text())
        assert a == b, f'{prefix} state differs on rank {rank}'
(root/'fixed/long_pair_validation.json').write_text(json.dumps(dict(
    status='PASS', sequence_length=8192, updates_per_arm=2, world_size=2,
    repeat=dict(sequence_length=128, updates_per_arm=6),
    full_parameters_optimizer_buffers_scheduler_groups_rng_equal=True,
    execution_order=['on', 'off']), indent=2))
print('LONG_PAIR_PASS', flush=True)
