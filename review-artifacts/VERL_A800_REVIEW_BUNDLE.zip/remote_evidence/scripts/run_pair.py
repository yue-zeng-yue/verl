"""Sequential, bounded formal GRPO pair; retain failed logs and stop on failure."""
from pathlib import Path
import json
import subprocess
import sys
import time
from summarize_grpo import summarize

root=Path(sys.argv[1]).resolve()
python='/root/venvs/verl-a800/bin/python'
ray='/root/venvs/verl-a800/bin/ray'
runs=[]
for name,lazy in [('grpo_off',False),('grpo_on',True)]:
    with (root/(name+'_ray_cleanup.log')).open('w') as f:
        subprocess.run([ray,'stop','--force'],stdout=f,stderr=subprocess.STDOUT,timeout=90)
    command=['timeout','--kill-after=30s','10860s',python,str(root/'scripts/run_grpo.py'),
             '--root',str(root),'--name',name,'--steps','100','--audit-checkpoints']+(['--lazy'] if lazy else [])
    start=time.time()
    with (root/(name+'_driver.log')).open('w') as f:
        code=subprocess.call(command,stdout=f,stderr=subprocess.STDOUT)
    runs.append(dict(name=name,command=command,start=start,end=time.time(),exit_code=code))
    (root/'pair_runs.json').write_text(json.dumps(runs,indent=2))
    assert code==0, runs[-1]
    result, _ = summarize(root/'results'/name)
    assert result['actor_updates']==100 and result['optimizer_steps']==400, result
    assert result['finite_grad_steps'] and result['nonzero_grad_steps']>0, result
    assert result['changed_probe_steps']>0 and result['groups_with_reward_variation']>0, result
    assert result['lazy_forward_cuda_state_violations']==0, result
    (root/'results'/name/'validated_summary.json').write_text(json.dumps(result,indent=2))
    print('RUN_COMPLETE',name,flush=True)
print('GRPO_PAIR_COMPLETE',flush=True)
