"""Deterministic GSM8K subset using official splits; no reward-based selection."""
from pathlib import Path
import hashlib
import json
import random
import re
import pyarrow as pa
import pyarrow.parquet as pq

root = Path(__file__).resolve().parents[1]
out = root/'data'
out.mkdir(exist_ok=True)
manifest = {'repository':'openai/gsm8k','revision':'740312add88f781978c0658806c59bc2815b9866','seed':5282,'splits':{}}
questions = {}
for split, count in [('train',1024),('test',128)]:
    paths = sorted((root/'raw_gsm8k/main').glob(split+'*.parquet'))
    assert paths
    raw = [row for path in paths for row in pq.read_table(path).to_pylist()]
    indexes = random.Random(5282).sample(range(len(raw)),count)
    rows = []
    for index in indexes:
        row = raw[index]
        answer = re.search(r'#### (\-?[0-9\.,]+)',row['answer'])
        assert answer
        rows.append({'data_source':'openai/gsm8k','prompt':[{'role':'user','content':row['question']+' Let\'s think step by step and output the final answer after "####".'}],
                     'ability':'math','reward_model':{'style':'rule','ground_truth':answer.group(1).replace(',','')},
                     'extra_info':{'split':split,'index':index,'answer':row['answer'],'question':row['question']}})
    pq.write_table(pa.Table.from_pylist(rows),out/(split+'.parquet'))
    questions[split] = {r['extra_info']['question'] for r in rows}
    manifest['splits'][split] = {'original_rows':len(raw),'selected_rows':count,'original_indexes':indexes,
        'parquet_sha256':hashlib.sha256((out/(split+'.parquet')).read_bytes()).hexdigest(),
        'source_files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
assert not questions['train'].intersection(questions['test'])
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('DATA_READY', {s:len(v) for s,v in questions.items()})
