"""Preserve the complete baseline checkpoint while making room for on/50 + on/100.

The 50 GiB data disk cannot hold three full 1.5B checkpoints during atomic rotation.
Move only verified optimizer shards to the persistent system disk and replace each
source path atomically with a symlink. No checkpoint state or file contents change.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import time

root=Path('/root/autodl-tmp/verl-a800')
checkpoint=root/'results/grpo_off/checkpoints/global_step_100/actor'
destination=Path('/root/verl-a800-checkpoint-optimizer/grpo_off_100')
deadline=time.monotonic()+10800
while not all((checkpoint/f'engine_fingerprint_rank_{rank}.json').exists() for rank in (0,1)):
    if time.monotonic()>deadline:
        raise TimeoutError('baseline checkpoint was not completed')
    time.sleep(10)
files=sorted(checkpoint.glob('optim_world_size_2_rank_*.pt'))
assert len(files)==2,files
required=sum(p.stat().st_size for p in files)
assert shutil.disk_usage('/root').free > required+2*1024**3, 'insufficient persistent system disk space'
destination.mkdir(parents=True,exist_ok=True)
record={'start_unix':time.time(),'purpose':'preserve complete checkpoints during atomic rotation','files':[]}
for source in files:
    target=destination/source.name
    assert not source.is_symlink() and not target.exists()
    temporary=target.with_suffix('.pt.partial')
    shutil.copy2(source,temporary)
    with temporary.open('rb') as stream:
        os.fsync(stream.fileno())
    def sha(path):
        with path.open('rb') as stream:
            return hashlib.file_digest(stream,'sha256').hexdigest()
    digest=sha(source)
    assert digest==sha(temporary), 'checkpoint copy checksum mismatch'
    temporary.replace(target)
    link=source.with_suffix('.pt.link')
    link.symlink_to(target)
    link.replace(source)
    record['files'].append({'source':str(source),'destination':str(target),'sha256':digest,'bytes':target.stat().st_size})
record['end_unix']=time.time()
record['data_free_bytes']=shutil.disk_usage(root).free
record['system_free_bytes']=shutil.disk_usage('/root').free
(root/'checkpoint_storage_manifest.json').write_text(json.dumps(record,indent=2))
print('CHECKPOINT_STORAGE_PRESERVED',json.dumps(record),flush=True)
