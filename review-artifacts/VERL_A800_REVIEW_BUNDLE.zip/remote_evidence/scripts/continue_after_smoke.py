from pathlib import Path
import json
import subprocess
import time
from summarize_grpo import summarize

root=Path('/root/autodl-tmp/verl-a800')
exit_path=root/'results/smoke_on_nested_3/exit.json'
deadline=time.monotonic()+1800
while not exit_path.exists():
    if time.monotonic()>deadline:
        raise TimeoutError('smoke completion missing after 30 minutes')
    time.sleep(10)
assert json.loads(exit_path.read_text())['exit_code']==0
result,_=summarize(exit_path.parent)
assert result['actor_updates']==3 and result['optimizer_steps']==12, result
assert result['finite_grad_steps'] and result['changed_probe_steps']>0, result
assert result['groups_with_reward_variation']>0, result
assert result['lazy_forward_cuda_state_violations']==0, result
(exit_path.parent/'validated_summary.json').write_text(json.dumps(result,indent=2))
print('SMOKE_VALIDATED',json.dumps(result),flush=True)
subprocess.run(['/root/venvs/verl-a800/bin/python',str(root/'scripts/run_pair.py'),str(root)],check=True)
