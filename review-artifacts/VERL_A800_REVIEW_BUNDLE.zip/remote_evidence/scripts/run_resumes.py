from pathlib import Path
import json
import hashlib
import struct
import subprocess
import sys
import torch
import pyarrow.parquet as pq
from summarize_grpo import summarize

root=Path('/root/autodl-tmp/verl-a800')
for source_name, name, enabled in [('grpo_off','resume_off_to_on_102',True),('grpo_on','resume_on_to_off_102',False)]:
    checkpoint=root/'results'/source_name/'checkpoints/global_step_100'
    assert checkpoint.exists(), checkpoint
    with (root/'logs'/f'{name}_cleanup.log').open('w') as log:
        subprocess.run(['/root/venvs/verl-a800/bin/ray','stop','--force'],stdout=log,stderr=subprocess.STDOUT,timeout=90)
    command=[sys.executable,str(root/'scripts/run_grpo_resume.py'),'--root',str(root),'--name',name,
             '--resume',str(checkpoint),'--steps','102','--save-freq','-1','--audit-checkpoints']+(['--lazy'] if enabled else [])
    with (root/'logs'/f'{name}_driver.log').open('w') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1200)
    summary,_=summarize(root/'results'/name)
    assert summary['actor_updates']==2 and summary['optimizer_steps']==8,summary
    assert summary['finite_grad_steps'] and summary['changed_probe_steps']>0
    assert len(list((root/'results'/name/'audit').glob('final_engine_rank_*.json')))==2
    checkpoint_data = torch.load(checkpoint/'data.pt', map_location='cpu', weights_only=False)
    assert checkpoint_data['_sampler_iter_state']['samples_yielded'] == 800, checkpoint_data
    expected_questions = {r['prompt'][0]['content'] for r in pq.read_table(root/'data/train.parquet').to_pylist()[800:816]}
    actual_inputs = {json.loads(line)['input'] for path in (root/'results'/name/'rollouts').glob('*.jsonl')
                     for line in path.read_text().splitlines() if line.strip()}
    assert len(actual_inputs) == len(expected_questions) == 16
    assert all(any(question in text for text in actual_inputs) for question in expected_questions)
    rows = [json.loads(line) for path in (root/'results'/name/'audit').glob('worker_*.jsonl')
            for line in path.read_text().splitlines() if line.strip()]
    loads = [r for r in rows if r['event'] == 'checkpoint_load_verified']
    assert sorted(r['rank'] for r in loads) == [0, 1]
    rank_checks = {}
    for rank in (0, 1):
        saved = json.loads((checkpoint/'actor'/f'engine_fingerprint_rank_{rank}.json').read_text())
        final = json.loads((root/'results'/name/'audit'/f'final_engine_rank_{rank}.json').read_text())
        for fingerprint, steps in ((saved, 400), (final, 408)):
            expected_sha = hashlib.sha256(struct.pack('<f', steps)).hexdigest()
            assert all(state['step']['sha256'] == expected_sha for state in fingerprint['optimizer'].values())
        assert saved['scheduler']['last_epoch'] == 100, saved['scheduler']
        assert final['scheduler']['last_epoch'] == 102, final['scheduler']
        changed_parameters = sum(v != final['parameters'][key] for key, v in saved['parameters'].items())
        changed_moments = sum(v['exp_avg'] != final['optimizer'][key]['exp_avg'] for key, v in saved['optimizer'].items())
        assert changed_parameters > 0 and changed_moments > 0
        rank_checks[str(rank)] = dict(all_adam_counters=[400, 408], scheduler_epochs=[100, 102],
                                     changed_parameters=changed_parameters, changed_moments=changed_moments)
    (root/'results'/name/'resume_validation.json').write_text(json.dumps(dict(
        status='PASS', complete_engine_state_restored_ranks=[0, 1], data_samples_before=800,
        resumed_exact_dataset_positions=[800, 816], per_rank=rank_checks), indent=2))
    (root/'results'/name/'validated_summary.json').write_text(json.dumps(summary,indent=2))
    print('RESUME_PASS',name,flush=True)
