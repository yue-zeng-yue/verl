"""Continue this active experiment after the formal pair passes."""
from pathlib import Path
import json
import subprocess
import time

root = Path('/root/autodl-tmp/verl-a800')
ready = root/'results/grpo_on/validated_summary.json'
deadline = time.monotonic() + 3 * 3600
while not ready.exists():
    for name in ('grpo_off', 'grpo_on'):
        p = root/'results'/name/'exit.json'
        if p.exists():
            assert json.loads(p.read_text())['exit_code'] == 0, p
    assert time.monotonic() < deadline, 'formal pair did not finish before deadline'
    time.sleep(10)
assert json.loads(ready.read_text())['optimizer_steps'] == 400
for script in ('run_resumes.py', 'run_long_pair.py'):
    subprocess.run(['/root/venvs/verl-a800/bin/python', str(root/'scripts'/script)], check=True)
(root/'validation_complete.json').write_text(json.dumps(dict(status='PASS', completed_unix=time.time())))
print('ALL_VALIDATION_COMPLETE', flush=True)
