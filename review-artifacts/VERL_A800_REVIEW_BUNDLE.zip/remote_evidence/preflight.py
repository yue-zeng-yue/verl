from pathlib import Path
import hashlib
import importlib.metadata
import json
import subprocess
import torch
import transformers
import vllm
import flash_attn
from verl.workers.config import FSDPEngineConfig
from verl.workers.engine.fsdp.transformer_impl import FSDPEngine

root=Path('/root/autodl-tmp/verl-a800')
assert torch.cuda.device_count()==2
assert torch.__version__=='2.11.0+cu130'
assert transformers.__version__=='5.9.0'
assert vllm.__version__=='0.24.0'
for i in range(2):
 with torch.cuda.device(i):
  x=torch.randn(128,128,device='cuda',dtype=torch.bfloat16)
  assert torch.isfinite(x@x).all()
  torch.cuda.synchronize()
record=dict(torch=torch.__version__,transformers=transformers.__version__,vllm=vllm.__version__,
 cuda=torch.version.cuda,source_file=__import__('inspect').getfile(FSDPEngine),
 config_default=FSDPEngineConfig().optimizer_offload_step,
 packages={d.metadata['Name']:d.version for d in importlib.metadata.distributions()},
 gpus=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,driver_version','--format=csv'],text=True))
record['model_sha256']={p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in (root/'model').glob('*') if p.is_file()}
(root/'preflight.json').write_text(json.dumps(record,indent=2))
print('PREFLIGHT_PASS',record['gpus'],flush=True)
