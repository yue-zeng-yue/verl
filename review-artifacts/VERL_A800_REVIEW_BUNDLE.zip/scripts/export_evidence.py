"""Download this instance's experiment records, excluding large model/state shards."""
from pathlib import Path
import hashlib
import json
import subprocess
import shlex
import sys
import time

root = Path(__file__).resolve().parents[1]
destination = root/'remote_evidence'
destination.mkdir(exist_ok=True)
command = ['rsync', '-az', '--exclude=/model/', '--exclude=/source/',
           '--exclude=/source_upstream/', '--exclude=/wheels/', '--exclude=/source.tar.gz',
           '--exclude=model_world_size_*.pt', '--exclude=optim_world_size_*.pt',
           '--exclude=*.partial', '--exclude=__pycache__/',
           '-e', f'ssh -F {root / "ssh_config"}',
           'a800:/root/autodl-tmp/verl-a800/', str(destination)+'/']
# rsync's remote-shell option parses whitespace, so quote the path explicitly.
command[command.index('-e') + 1] = 'ssh -F ' + shlex.quote(str(root/'ssh_config'))
subprocess.run(command, check=True)
manifest = {}
for path in sorted(destination.rglob('*')):
    if path.is_file() and not path.is_symlink():
        with path.open('rb') as stream:
            manifest[str(path.relative_to(destination))] = dict(
                bytes=path.stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())
(root/'evidence_manifest.json').write_text(json.dumps(dict(
    exported_unix=time.time(), files=manifest,
    excluded='Original model weights and large model/optimizer checkpoint shards remain on the instance.'), indent=2))
print('EXPORTED', len(manifest), 'files', sum(v['bytes'] for v in manifest.values()), 'bytes')
if '--verify' in sys.argv:
    code = '''import sys,json,hashlib
from pathlib import Path
root=Path('/root/autodl-tmp/verl-a800')
out={}
for relative in json.load(sys.stdin):
    path=root/relative
    assert path.resolve().is_relative_to(root)
    if not path.is_file():
        out[relative]=None
        continue
    with path.open('rb') as stream:
        out[relative]=hashlib.file_digest(stream,'sha256').hexdigest()
print(json.dumps(out))
'''
    remote = subprocess.check_output(['ssh', '-F', str(root/'ssh_config'), 'a800',
                                     shlex.join(['/root/venvs/verl-a800/bin/python', '-c', code])],
                                    input=json.dumps(list(manifest)).encode())
    remote = json.loads(remote)
    mismatches = [path for path, digest in remote.items() if digest is not None and digest != manifest[path]['sha256']]
    assert not mismatches, mismatches
    verification = dict(status='PASS', verified_unix=time.time(),
                        matching_remote_files=sum(v is not None for v in remote.values()),
                        retained_earlier_exports_no_longer_on_remote=[p for p, v in remote.items() if v is None])
    (root/'evidence_verification.json').write_text(json.dumps(verification, indent=2))
    print('VERIFIED', verification['matching_remote_files'], 'remote SHA256 digests')
