"""Plot exported measurements; no inference about model quality."""
from pathlib import Path
from collections import defaultdict
import json
import statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parents[1]
results_root=root/'results' if (root/'results').exists() else root/'remote_evidence/results'
fig,axes=plt.subplots(2,2,figsize=(12,7),constrained_layout=True)
colors={'grpo_off':'#53657a','grpo_on':'#008b76'}
all_data={}
for name in colors:
    path=results_root/name
    rows=[json.loads(line) for p in sorted((path/'audit').glob('worker_*.jsonl')) for line in p.read_text().splitlines() if line.strip()]
    ranks=defaultdict(list)
    for row in rows:
        if row['event']=='actor_update': ranks[row['rank']].append(row)
    for rows_rank in ranks.values(): rows_rank.sort(key=lambda r:r['time'])
    assert set(ranks)=={0,1} and len(ranks[0])==len(ranks[1])==100
    memory=[max(a['after']['peak_allocated'],b['after']['peak_allocated'])/2**30 for a,b in zip(ranks[0],ranks[1])]
    seconds=[max(a['seconds'],b['seconds']) for a,b in zip(ranks[0],ranks[1])]
    metrics=[json.loads(line) for line in (path/'metrics.jsonl').read_text().splitlines()]
    steady=[r['data']['timing_s/step'] for r in metrics if r['step'] not in (0,1,2,3,4,5,50,100)]
    summary=json.loads((path/'validated_summary.json').read_text())
    all_data[name]=(memory,seconds,steady,summary)
    label='Off (default)' if name.endswith('off') else 'On (opt-in)'
    axes[0,0].plot(range(1,101),memory,color=colors[name],label=label,lw=1.4)
    axes[0,1].plot(range(1,101),seconds,color=colors[name],alpha=.7,lw=1.1,label=label)

for axis,title,ylabel in [(axes[0,0],'Full actor-window peak (maximum of ranks)','Allocated memory (GiB / GPU)'),(axes[0,1],'Full actor window, including state transfers','Time (s / GRPO step)')]:
    axis.set(title=title,xlabel='GRPO step',ylabel=ylabel)
    axis.grid(axis='y',alpha=.2);axis.legend(frameon=False)
labels=['Off','On']
for i,name in enumerate(colors):
    mem,sec,steady,summary=all_data[name]
    values=[max(mem),summary['device_memory_sampled_peak_bytes']/2**30]
    xs=[0+i*.3,1+i*.3]
    bars=axes[1,0].bar(xs,values,width=.28,color=colors[name],label=labels[i])
    axes[1,0].bar_label(bars,fmt='%.2f',padding=3,fontsize=9)
    values=[statistics.median(sec[5:]),statistics.median(steady)]
    bars=axes[1,1].bar(xs,values,width=.28,color=colors[name],label=labels[i])
    axes[1,1].bar_label(bars,fmt='%.2f',padding=3,fontsize=9)
axes[1,0].set(xticks=[.15,1.15],xticklabels=['Actor allocated peak','Whole-run NVML peak'],ylabel='GiB / GPU',title='Training and whole-run peaks are different measures')
axes[1,1].set(xticks=[.15,1.15],xticklabels=['Actor median (steps 6–100)','Steady GRPO step median'],ylabel='Seconds',title='Steady step median excludes validation/checkpoint steps')
for axis in axes.flat:
    axis.spines[['top','right']].set_visible(False)
    axis.tick_params(labelsize=9)
analysis=json.loads((root/'analysis.json').read_text())
off_tokens=analysis['grpo_off']['training_response_tokens_from_logged_mean']
on_tokens=analysis['grpo_on']['training_response_tokens_from_logged_mean']
fig.suptitle('2 × A800 80GB PCIe · Qwen2.5-1.5B · GSM8K · 100 GRPO steps per arm\n'
             f'Response tokens: {off_tokens:,} off / {on_tokens:,} on · Different trajectories; times do not isolate transfer overhead',fontsize=11.5)
fig.savefig(root/'grpo_benchmark.png',dpi=180)
fig.savefig(root/'grpo_benchmark.svg')
