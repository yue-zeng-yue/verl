"""Derive reviewable comparisons from completed raw records."""
from collections import defaultdict
from pathlib import Path
import json
import statistics
from summarize_grpo import read_rows, summarize

root = Path(__file__).resolve().parents[1]
results_root = root/'results' if (root/'results').exists() else root/'remote_evidence/results'
results, updates, commands, prompts, generations = {}, {}, {}, {}, {}
sampling = {}

def normalize(text):
    return (text.replace('grpo_off', 'ARM').replace('grpo_on', 'ARM')
            .replace('optimizer_offload_step=False', 'optimizer_offload_step=SWITCH')
            .replace('optimizer_offload_step=True', 'optimizer_offload_step=SWITCH'))

for name in ('grpo_off', 'grpo_on'):
    path = results_root/name
    summary, observations = summarize(path)
    assert summary['exit_code'] == 0
    assert summary['actor_updates'] == 100 and summary['optimizer_steps'] == 400
    assert summary['finite_grad_steps'] and summary['lazy_forward_cuda_state_violations'] == 0
    assert summary['nonzero_grad_steps'] == summary['changed_probe_steps'] == 800
    rows = read_rows(path/'metrics.jsonl')
    train_rows = [r for r in rows if 1 <= r['step'] <= 100]
    assert len(train_rows) == 100
    steady = [r['data']['timing_s/step'] for r in rows if r['step'] not in (0, 1, 2, 3, 4, 5, 50, 100)]
    summary.update(steady_step_median_seconds=statistics.median(steady),
                   steady_step_mean_seconds=statistics.mean(steady),
                   steady_step_samples=len(steady),
                   sampled_actor_process_peak_host_rss_bytes=max(r['after']['host_rss'] for r in observations))
    summary['training_response_tokens_from_logged_mean'] = round(sum(r['data']['response_length/mean'] * 32 for r in train_rows))
    summary['training_prompt_tokens_in_response_batch_from_logged_mean'] = round(sum(r['data']['prompt_length/mean'] * 32 for r in train_rows))
    adam = [r for file in (path/'audit').glob('worker_*.jsonl') for r in read_rows(file) if r['event'] == 'optimizer_step']
    summary['post_adam_cuda_state_nonzero_records'] = sum(r['state_after'].get('cuda', 0) > 0 for r in adam)
    summary['post_adam_cpu_state_bytes'] = sorted({r['state_after'].get('cpu', 0) for r in adam})
    if name == 'grpo_on':
        assert summary['post_adam_cuda_state_nonzero_records'] == 0
        assert summary['post_adam_cpu_state_bytes'] == [6174858568]
    for rank in (0, 1):
        rank_rows = sorted((r for r in observations if r['rank'] == rank), key=lambda r: r['time'])
        # A fixed observation window describes residency; it does not prove absence of all leaks.
        summary['per_rank'][str(rank)]['post_context_allocated_first20_median_bytes'] = statistics.median(r['after']['allocated'] for r in rank_rows[5:25])
        summary['per_rank'][str(rank)]['post_context_allocated_last20_median_bytes'] = statistics.median(r['after']['allocated'] for r in rank_rows[-20:])
    updates[name] = sorted(observations, key=lambda r: (r['rank'], r['time']))
    commands[name] = json.loads((path/'command.json').read_text())
    sampling[name] = sorted((r['step'], r['prompt_sha256'], r['session'], r['seed'])
                            for file in (path/'audit').glob('sampling_*.jsonl') for r in read_rows(file))
    groups = defaultdict(list)
    for file in (path/'rollouts').glob('*.jsonl'):
        for row in read_rows(file):
            groups[row['input']].append(row['output'])
    assert len(groups) == 800 and all(len(v) == 4 for v in groups.values())
    prompts[name] = set(groups)
    generations[name] = {key: sorted(values) for key, values in groups.items()}
    summary['actual_distinct_training_prompts'] = len(groups)
    summary['actual_generated_training_responses'] = sum(map(len, groups.values()))
    results[name] = summary

assert prompts['grpo_off'] == prompts['grpo_on']
assert sampling['grpo_off'] == sampling['grpo_on'] and len(sampling['grpo_off']) == 3584
assert [normalize(x) for x in commands['grpo_off']['command']] == [normalize(x) for x in commands['grpo_on']['command']]
assert {k: normalize(v) for k, v in commands['grpo_off']['env'].items()} == {k: normalize(v) for k, v in commands['grpo_on']['env'].items()}
a, b = results['grpo_off'], results['grpo_on']
initial = {name: {r['input']: r['output'] for r in read_rows(results_root/name/'validation/0.jsonl')}
           for name in ('grpo_off', 'grpo_on')}
assert initial['grpo_off'].keys() == initial['grpo_on'].keys()
results['comparison'] = dict(
    effective_configuration_equal_except_switch_and_output_paths=True,
    training_prompt_set_identical=True,
    identical_sampling_requests=3584,
    exact_actor_input_matches=sum(x['inputs'] == y['inputs'] for x, y in zip(updates['grpo_off'], updates['grpo_on'])),
    actor_rank_input_pairs=200,
    initial_validation_identical_outputs=sum(value == initial['grpo_on'][key] for key, value in initial['grpo_off'].items()),
    initial_validation_prompt_pairs=len(initial['grpo_off']),
    prompts_with_identical_response_multisets=sum(generations['grpo_off'][key] == generations['grpo_on'][key] for key in prompts['grpo_off']),
    actor_peak_saved_bytes=a['actor_window_peak_allocated_bytes']-b['actor_window_peak_allocated_bytes'],
    actor_peak_saved_percent=100*(1-b['actor_window_peak_allocated_bytes']/a['actor_window_peak_allocated_bytes']),
    whole_nvml_peak_saved_percent=100*(1-b['device_memory_sampled_peak_bytes']/a['device_memory_sampled_peak_bytes']),
    actor_steady_median_time_change_percent=100*(b['actor_seconds_steady_median']/a['actor_seconds_steady_median']-1),
    steady_step_median_time_change_percent=100*(b['steady_step_median_seconds']/a['steady_step_median_seconds']-1),
    wall_time_change_percent=100*(b['wall_seconds']/a['wall_seconds']-1),
    caveat='One GRPO trial per arm; generated trajectories may differ. Fixed-input state equivalence is tested separately. NVML peaks are sampled. Whole wall includes initialization, validation, checkpoints and audit overhead.')
(root/'analysis.json').write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results['comparison'], indent=2))
