# 新版 VERL FSDP2 优化器按步卸载：双 A800 验证报告

实验于 2026-09-07 启动。此文件从已完成的原始记录生成，统计脚本见 `scripts/analyze_experiment.py` 和 `scripts/write_report.py`。

## 结论与边界

实现已落在新版 FSDP Engine，默认关闭。双 A800 的每组 100 步 GRPO 对照中，actor 完整训练窗口的每卡 allocated 峰值从 **14.693 GiB 降至 12.372 GiB，节省 15.80%**。同一次对照中，观察到 actor 稳态中位耗时变化 **+9.56%**，整体稳态训练步中位耗时变化 **-5.47%**。

两臂生成长度不同：关闭组 872551 个回答 token，开启组 693670 个，开启组少 20.50%。因此这些 GRPO 时间差不是等 token 工作负载下的纯搬运开销，整体训练步变快也不能作为加速证据。相同输入的数值与性能对照另行列出。

这是显存与搬运时间之间的可选权衡，不能描述为普遍加速或模型质量改进。整卡 NVML 峰值与 actor 张量峰值分开统计；rollout、初始化和其他进程的内存可能决定整卡峰值。当前 A800 配置并未因显存耗尽而失败，不能据此声称扩大了这台机器的最大可训练模型。

每个 rank 约 5.75 GiB 的 Adam 状态离开前向/反向阶段，并不意味着完整窗口一定减少 5.75 GiB：执行 Adam 更新时仍需要这些状态，更新阶段本身可能成为新的峰值。输入长度、微批大小和每个窗口的更新次数都会改变收益与代价。

固定输入检查比较了完整参数、Adam 状态、缓冲区、scheduler、参数组及 RNG；真实 GRPO 完成了更新、保存、验证和跨开关恢复。已有可用于 PR 评审的实现与证据，但是否合并仍由维护者判断。

## 设计与模块位置

| 内容 | 位置及行为 |
|---|---|
| 配置 | `verl/workers/config/engine.py`、`verl/trainer/config/engine/fsdp.yaml`：新增 `optimizer_offload_step=False`，生成配置同步更新 |
| 训练上下文 | `verl/workers/engine/fsdp/transformer_impl.py` 的 `EngineTrainModeCtx`：开启后跳过 optimizer 预加载，参数和梯度仍使用原接口 |
| 更新 | 同文件 `FSDPEngine.optimizer_step`：原梯度裁剪和有限性检查之后加载 Adam 状态，执行更新，`finally` 卸载 |
| 嵌套调用 | TrainingWorker 的内层手动上下文继承外层按步策略；顶层 `disable_auto_offload=True` 仍由调用者管理 |
| 回归 | CPU 生命周期与配置测试、`tests/special_distributed` 真实 DTensor 双卡测试，接入现有测试入口 |
| 文档 | 现有 `docs/perf/perf_tuning.rst`，说明配置、支持范围和搬运代价 |

首版限定手动 offload 的 FSDP2、标准 `torch.optim.AdamW`、无梯度 scaler；普通、foreach、fused AdamW 已测试。参数 offload 可以独立开关。不支持的自动卸载组合明确报错；默认关闭不增加这些限制。共享 BaseEngine、GRPO 算法、奖励、rollout 和检查点序列化格式没有进入实现 diff。

## 基线与实际环境

- 实验源代码：`c80729fbdfdd3fc46a5b224a23cb04aab8f5e51d` 加 `implementation.patch`。
- 交付分支 main 基线：`d040717b21af2e23e8e789a3e354cff2394ae2de`。新增上游提交仅修改 Ascend vLLM 补丁；本特性 patch 字节完全一致，对齐后 58 项 CPU 测试和全部 pre-commit 再次通过。
- AutoDL 实例 `2201459dc8-481a6a0e`，同机 **2×A800 80GB PCIe**，28 CPU / 240 GB RAM。两卡拓扑为跨 NUMA 的 SYS，**没有 NVLink**。
- Python 3.12、PyTorch 2.11.0+cu130、Transformers 5.9.0、vLLM 0.24.0、FlashAttention 2.8.3。NumPy 按声明依赖调整为 2.3.5；最终依赖检查通过。此环境修正没有混入 PR。
- 模型 Qwen2.5-1.5B-Instruct，revision `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`。
- 仅 **GSM8K 一个数据集**，revision `740312add88f781978c0658806c59bc2815b9866`。固定随机种子选取 1024 道训练题与独立 128 道验证题，没有按奖励挑选数据；长度过滤后数量不变。
- actor/ref 为 world_size=2 的 FSDP2；rollout 为两个 TP=1 副本。微批、精度、模型、数据、seed 和有效参数均保持一致，只有开关及输出名称/路径不同。

## GRPO 实际运行量与性能

每组 100 个 GRPO 步 × 8 道题 = **800 道实际训练题**；每题四个回答，共 **3200 个生成回答**。每步两个 actor epoch、四次全局 Adam 更新，因此每组是 **400 次 Adam 更新**。两组使用同样的 800 道题。双卡日志记录数为每组 800 条 rank 更新，不能将其算成 800 次全局 Adam 更新。

这不是训练完整个 1024 题子集的一轮，也不是收敛实验。整个训练/生成/验证/保存流程跑通，与“训练到收敛”是两件事。使用共享 `main_ppo` 入口，但算法设置为 GRPO，没有运行 PPO/GAE 或 critic 训练测试。

| 指标 | 关闭 | 开启 |
|---|---:|---:|
| GRPO 步 / 全局 Adam 更新 | 100 / 400 | 100 / 400 |
| 有限、非零梯度且探针变化的 rank 更新 | 800 / 800 | 800 / 800 |
| 训练回答 token 总数，按记录的 response length 汇总 | 872551 | 693670 |
| 每卡 actor 完整窗口峰值 allocated，取较大 rank | 14.693 GiB | 12.372 GiB |
| 整卡 NVML 采样峰值，取较大 GPU | 21.621 GiB | 21.623 GiB |
| actor 窗口稳态中位时间，含所有搬运 | 10.566 s | 11.577 s |
| 整体稳态训练步中位时间 | 27.925 s | 26.398 s |
| 进程启动至退出，含初始化/验证/保存/审计 | 52.27 min | 50.28 min |

actor 稳态统计取第 6–100 步，每步使用较慢 rank 的完整上下文时间；整体稳态统计还排除 50/100 的检查点步骤。NVML 每 0.1 秒采样，不能视为连续采样的绝对峰值。关闭组最终检查点曾转存到系统盘以避免 50 GiB 数据盘轮换超限，转存发生在 actor 窗口之外；**全程时间包含不同的实验存储工作，不作纯粹性能归因**。

开启组全部已观测前向/反向调用的 CUDA optimizer 状态违规数为 0；每个 actor 窗口结束后优化器 CUDA 状态为 0，CPU 状态每 rank 为 6174858568 字节。
此外，800 条 rank 级 Adam 更新记录中，更新后 CUDA 状态非零的记录为 0 条，证明状态是在每次 Adam 更新结束后卸载。

## 数值正确性、恢复和输入规模

- 58 项 Linux CPU 回归通过；交付 main 上的 58 项 CPU 回归再次通过。所有仓库 pre-commit 检查通过。
- 真实双卡 DTensor 测试通过六种组合：参数 offload 开/关 × 普通/foreach/fused AdamW。覆盖完整本地分片、梯度累积、跨 rank 非有限梯度跳过、状态重载及嵌套上下文。
- 初始完整 Qwen 固定输入矩阵：单卡 upstream/off/on、双卡 off/on，各六次更新，完整状态指纹相等。该矩阵先于嵌套上下文修正，最终代码另由双卡回归、GRPO 和下表的完整模型复测覆盖。
- 两个实际 GRPO 恢复方向均通过：off100→on102、on100→off102。每 rank 完整 engine 状态在加载后匹配保存状态，所有 Adam counter 从 400 到 408，scheduler 从 100 到 102；继续处理的是原数据集位置 800–815 的 16 道题。恢复测试关闭重复验证和检查点写入，检查的是接续正确性，不能作为第三、第四组性能对照。

并非所有配置都有可观收益。最初单 A800、128 token、六次更新的固定输入检查中，关闭/开启的完整峰值分别为 24.991 / 24.814 GiB，而窗口耗时为 9.164 / 14.809 秒：显存节省很小，时间代价较大。该小样本结果同样保留于 `fixed_short_summary.json`，不能只选择有利配置报告。

最终代码的短输入反序复测和长输入检查如下，每一对都先开后关，并在两个 rank 比较完整状态指纹：

| 固定输入运行 | 序列长度 | 每组更新数 | 较大 rank 的完整峰值 GiB | 较慢 rank 的完整窗口秒数 |
|---|---:|---:|---:|---:|
| repeat128_off | 128 | 6 | 15.703 | 9.976 |
| repeat128_on | 128 | 6 | 12.472 | 12.511 |
| long8192_off | 8192 | 2 | 24.487 | 15.777 |
| long8192_on | 8192 | 2 | 18.737 | 16.473 |

8192 token 只跑两次更新，用于覆盖 Adam 状态初始化后的长输入窗口；它不是稳定吞吐量统计，也没有建立 A800 的最大容量边界。固定输入探针使用 engine 的语言模型损失检查数值一致性，不是另一次 PPO 实验。

## 生成随机性与质量解释

两组全部 3584 个训练/验证采样请求的 prompt、step、session 和 seed 对齐。但初始验证已有 6 / 128 个输出不同；框架的 full-determinism 设置和固定 seed 未在该生成链路达到逐字确定性。

| 验证步，独立 128 题 | 关闭 | 开启 |
|---|---:|---:|
| 0 | 64.06% | 64.84% |
| 50 | 75.78% | 73.44% |
| 100 | 75.00% | 75.78% |

训练中有 0 / 200 对 rank 输入指纹完全相等，7 / 800 道训练题的四个回答集合完全相同。不能将质量分数差异直接归因于卸载策略。这里每臂仅一个真实 GRPO 试验，不报告跨 seed 的显著性或泛化结论；严格数值等价由固定输入检查支持。

## 实验中修复的问题与可复现性

首次开启组预检 `smoke_on_3` 失败：TrainingWorker 的内层 `disable_auto_offload=True` 错误取消了外层按步策略。随后改为继承外层状态，补充 CPU 和真实分片回归，新的 `smoke_on_nested_3` 三步预检通过，再启动正式 A/B。失败日志保留，没有将失败运行算作成功。

测量 observer、不同 response 的确定性 seed wrapper、奖励包装与报告脚本均在实验目录中，不进入 PR。奖励包装调用 VERL 自带 flexible GSM8K scorer，保留 strict-format score。正式训练的核心代码与 observer 未在 A/B 之间修改。

设计承接 issue [#5282](https://github.com/verl-project/verl/issues/5282) 及已关闭前作 [#5657](https://github.com/verl-project/verl/pull/5657)，遵循维护者转向新 FSDP Engine 的意见。用户 GDPO 经 [#5503](https://github.com/verl-project/verl/pull/5503) 合并的经验，借鉴的是将专属逻辑放回负责该职责的模块，不能据此保证本 PR 获得同样结论。

代码、命令、模型/数据 revision、完整审计摘要、日志和依赖记录均已落盘。参见 `REPRODUCE.md`、`analysis.json`、`evidence_manifest.json` 及 `evidence_verification.json`。大体积模型/优化器 checkpoint shard 保留在实例的系统盘和数据盘，元数据及状态指纹已导出；本地证据包不含这些大分片。实例最终状态以 `STATUS.json` 为准。
