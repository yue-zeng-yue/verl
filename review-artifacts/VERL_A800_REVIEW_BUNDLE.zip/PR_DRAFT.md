# [perf, fsdp2] Keep optimizer states on CPU between updates

With manual optimizer offloading, the FSDP Engine loads optimizer states on entering a training context. When that context spans several mini-batches or epochs, Adam states remain on the GPU during forward and backward computation. Add `optimizer_offload_step=False` so memory-constrained users can keep those states on CPU until an actual parameter update.

The behavior lives in the FSDP Engine's training context and finite-gradient update branch. It reuses existing transfers, loads states after gradient clipping, and offloads them in `finally` after `optimizer.step()`. Nested manual contexts retain the outer automatic context's policy; a top-level `disable_auto_offload=True` keeps caller-managed transfers. The default path, shared BaseEngine, training algorithms, and checkpoint format are unchanged.

The option requires FSDP2, manual `optimizer_offload=True`, `offload_policy=False`, and standard `torch.optim.AdamW` without a gradient scaler. Parameter offloading is independent. Ordinary, foreach, and fused AdamW variants are covered. Unsupported opt-in configurations fail explicitly.

Related to #5282. This builds on the direction explored in the closed #5657 and follows the maintainer's request to implement it in the new FSDP Engine.

## Validation

- 58 selected CPU configuration and Engine regression tests passed; all repository pre-commit hooks passed. Both passed again after aligning the branch to main `d040717`.
- Real two-rank DTensor tests cover six parameter-offload/AdamW combinations, complete local parameter and optimizer equality, gradient accumulation, global nonfinite-gradient skipping, nested contexts, and state reload across the option change.
- Full Qwen2.5-1.5B fixed-input checks compare single-GPU upstream/off/on and dual-GPU off/on fingerprints. Final-source dual-GPU 128-token repetition and 8192-token checks match complete parameter, optimizer, buffer, scheduler, parameter-group and RNG fingerprints on both ranks.
- Two A800 GRPO trials completed 100 steps / 400 global Adam updates each, with validation and checkpoints at 50/100. Both actual checkpoint resume directions passed through step 102: complete actor state restored, Adam counters 400→408, scheduler 100→102, and the next 16 dataset examples consumed.

## Benchmark

Same host, 2×A800 80GB PCIe (SYS topology, no NVLink), Qwen2.5-1.5B-Instruct, GSM8K, two-rank FSDP2 actor/reference and two TP=1 rollout replicas. Each trial consumed 800 prompts and generated four responses per prompt; each actor window performed four global Adam updates. Only the option and output paths/names differ in the effective configuration.

| Metric | Off | On |
|---|---:|---:|
| Full actor-window allocated peak, maximum rank | 14.693 GiB | 12.372 GiB |
| Whole-run sampled NVML peak, maximum GPU | 21.621 GiB | 21.623 GiB |
| Steady actor-window median, including transfers | 10.566 s | 11.577 s |
| Steady training-step median | 27.925 s | 26.398 s |

Actor peak decreases by 15.80%, with +9.56% actor median time. Actor and whole-GPU peaks measure different scopes; rollout memory can dominate the latter. The single-GPU 128-token case had little memory benefit and appreciable transfer overhead, supporting an opt-in default.

These are one GRPO trial per arm, with different generated trajectories despite matching sampling requests; they do not establish a quality improvement or a general speedup. Steady actor statistics exclude the first five steps; steady training-step statistics also exclude checkpoint steps. Full wall times include initialization, validation and checkpoint auditing, including baseline checkpoint relocation for disk capacity, so they are not used for pure performance attribution. Strict numerical equivalence is checked separately with fixed inputs. GPU runs use `c80729f`; the subsequent main delta only touches the Ascend vLLM patch and leaves this feature patch byte-identical.

The off/on trials generated 872551 / 693670 response tokens respectively. The shorter enabled trajectory means the GRPO timing comparison does not isolate transfer overhead; its lower overall step time is not evidence of a speedup.

AI assistance: Codex was used for implementation, tests, experiment automation, and writing.
