"""Run the official VERL V1 synchronous trainer with GRPO, on one GPU."""
from pathlib import Path
import argparse
import json
import os
import subprocess
import sys
import time
import threading
import csv

p=argparse.ArgumentParser()
p.add_argument('--root',required=True)
p.add_argument('--name',required=True)
p.add_argument('--lazy',action='store_true')
p.add_argument('--steps',type=int,default=20)
p.add_argument('--seed',type=int,default=5282)
p.add_argument('--resume')
a=p.parse_args()
root=Path(a.root).resolve()
base=root.parent
out=root/'results'/a.name
out.mkdir(parents=True,exist_ok=False)
source=base/'ab_20260905_153700/source_lazy'
python=str(base/'.venv-grpo/bin/python')
overrides=[
    'trainer.use_v1=True','trainer.v1.trainer_mode=sync','algorithm.adv_estimator=grpo',
    'algorithm.use_kl_in_reward=False','algorithm.norm_adv_by_std_in_grpo=True',
    f'data.train_files={root}/data/train.parquet',f'data.val_files={root}/data/test.parquet',
    'data.train_batch_size=8','data.val_batch_size=16','data.max_prompt_length=512','data.max_response_length=512',
    'data.filter_overlong_prompts=True','data.filter_overlong_prompts_workers=1','data.truncation=error',
    'data.shuffle=False',f'data.seed={a.seed}','data.dataloader_num_workers=0',
    f'actor_rollout_ref.model.path={root}/model','actor_rollout_ref.model.external_lib=grpo_probe',
    'actor_rollout_ref.model.use_remove_padding=False','actor_rollout_ref.model.enable_gradient_checkpointing=True',
    '+actor_rollout_ref.model.override_config.attn_implementation=sdpa',
    'actor_rollout_ref.actor.strategy=fsdp2','actor_rollout_ref.actor.fsdp_config.strategy=fsdp2',
    'actor_rollout_ref.actor.fsdp_config.fsdp_size=1','actor_rollout_ref.actor.fsdp_config.model_dtype=fp32',
    'actor_rollout_ref.actor.fsdp_config.param_offload=True','actor_rollout_ref.actor.fsdp_config.optimizer_offload=True',
    'actor_rollout_ref.actor.fsdp_config.offload_policy=False',
    f'actor_rollout_ref.actor.fsdp_config.optimizer_offload_step={a.lazy}',
    'actor_rollout_ref.actor.fsdp_config.use_torch_compile=False',
    f'actor_rollout_ref.actor.fsdp_config.seed={a.seed}','actor_rollout_ref.actor.fsdp_config.full_determinism=True',
    'actor_rollout_ref.actor.optim.lr=1e-6','actor_rollout_ref.actor.optim.lr_scheduler_type=constant',
    'actor_rollout_ref.actor.optim.override_optimizer_config={foreach:false,fused:false}',
    'actor_rollout_ref.actor.ppo_mini_batch_size=4','actor_rollout_ref.actor.ppo_micro_batch_size_per_gpu=4',
    'actor_rollout_ref.actor.ppo_epochs=2','actor_rollout_ref.actor.use_dynamic_bsz=False',
    'actor_rollout_ref.actor.use_torch_compile=False',
    'actor_rollout_ref.actor.shuffle=False',f'actor_rollout_ref.actor.data_loader_seed={a.seed}',
    'actor_rollout_ref.actor.use_kl_loss=True','actor_rollout_ref.actor.kl_loss_coef=0.001',
    'actor_rollout_ref.actor.kl_loss_type=low_var_kl','actor_rollout_ref.actor.entropy_coeff=0',
    'actor_rollout_ref.ref.strategy=fsdp2','actor_rollout_ref.ref.fsdp_config.strategy=fsdp2',
    'actor_rollout_ref.ref.fsdp_config.fsdp_size=1','actor_rollout_ref.ref.fsdp_config.param_offload=True',
    'actor_rollout_ref.ref.fsdp_config.use_torch_compile=False','actor_rollout_ref.ref.log_prob_micro_batch_size_per_gpu=4',
    'actor_rollout_ref.rollout.name=vllm','actor_rollout_ref.rollout.mode=async',
    'actor_rollout_ref.rollout.tensor_model_parallel_size=1','actor_rollout_ref.rollout.n=4',
    'actor_rollout_ref.rollout.gpu_memory_utilization=0.25','actor_rollout_ref.rollout.enforce_eager=True',
    'actor_rollout_ref.rollout.free_cache_engine=True','actor_rollout_ref.rollout.max_model_len=1024',
    'actor_rollout_ref.rollout.max_num_batched_tokens=4096','actor_rollout_ref.rollout.max_num_seqs=32',
    'actor_rollout_ref.rollout.log_prob_micro_batch_size_per_gpu=4','actor_rollout_ref.rollout.log_prob_use_dynamic_bsz=False',
    'actor_rollout_ref.rollout.temperature=1.0','actor_rollout_ref.rollout.top_p=1.0',
    'actor_rollout_ref.rollout.full_determinism=True',f'actor_rollout_ref.rollout.seed={a.seed}',
    'actor_rollout_ref.rollout.val_kwargs.do_sample=False','actor_rollout_ref.rollout.val_kwargs.n=1',
    'actor_rollout_ref.rollout.agent.num_workers=1','reward.num_workers=1',
    'actor_rollout_ref.rollout.agent.default_agent_loop=grpo_seeded_single_turn',
    f'actor_rollout_ref.rollout.agent.agent_loop_config_path={root}/scripts/agent_loops.yaml',
    f'reward.custom_reward_function.path={root}/scripts/grpo_reward.py',
    'transfer_queue.backend.SimpleStorage.num_data_storage_units=1',
    'transfer_queue.backend.SimpleStorage.total_storage_size=2048',
    'trainer.nnodes=1','trainer.n_gpus_per_node=1','trainer.logger=[console,file]',
    'trainer.project_name=verl_grpo_lazy_offload',f'trainer.experiment_name={a.name}',
    f'trainer.total_training_steps={a.steps}','trainer.total_epochs=2',
    f'trainer.default_local_dir={out}/checkpoints','trainer.save_freq=10',
    'trainer.max_actor_ckpt_to_keep=2','trainer.test_freq=10','trainer.val_before_train=True',
    f'trainer.validation_data_dir={out}/validation',f'trainer.rollout_data_dir={out}/rollouts',
    'trainer.resume_mode=disable','ray_kwargs.ray_init.num_cpus=16',
    '+ray_kwargs.ray_init.include_dashboard=False','+ray_kwargs.ray_init.object_store_memory=2147483648',
]
if a.resume:
    overrides=[x for x in overrides if not x.startswith('trainer.resume_mode=')]
    overrides += ['trainer.resume_mode=resume_path',f'trainer.resume_from_path={a.resume}']
env=dict(os.environ,PYTHONPATH=os.pathsep.join([str(root/'scripts'),str(source)]),
         GRPO_AUDIT_DIR=str(out/'audit'),VERL_FILE_LOGGER_PATH=str(out/'metrics.jsonl'),
         VERL_USE_EXTERNAL_PLUGINS='none',VERL_DISABLE_FLASH_ATTN_CE='1',TOKENIZERS_PARALLELISM='false',
         WANDB_MODE='disabled',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
         PYTHONHASHSEED=str(a.seed),CUBLAS_WORKSPACE_CONFIG=':4096:8',OMP_NUM_THREADS='4',
         RAY_DEDUP_LOGS='0',HYDRA_FULL_ERROR='1')
command=[python,'-m','verl.trainer.main_ppo',*overrides]
(out/'command.json').write_text(json.dumps({'command':command,'env':{k:env[k] for k in ['PYTHONPATH','GRPO_AUDIT_DIR','VERL_FILE_LOGGER_PATH','PYTHONHASHSEED','CUBLAS_WORKSPACE_CONFIG','OMP_NUM_THREADS']}},indent=2))
start=time.time()
import pynvml
pynvml.nvmlInit()
uuids=subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).strip().splitlines()
assert len(uuids)==1, uuids
handle=pynvml.nvmlDeviceGetHandleByUUID(uuids[0])
stop=threading.Event()
def monitor():
    with (out/'gpu_samples.csv').open('w') as f:
        writer=csv.writer(f)
        writer.writerow(['time_unix','memory_used_bytes','memory_total_bytes','gpu_utilization_percent'])
        while not stop.is_set():
            m=pynvml.nvmlDeviceGetMemoryInfo(handle)
            util=pynvml.nvmlDeviceGetUtilizationRates(handle)
            writer.writerow([time.time(),m.used,m.total,util.gpu])
            f.flush()
            stop.wait(.1)
monitor_thread=threading.Thread(target=monitor,daemon=True)
monitor_thread.start()
with (out/'train.log').open('w') as log:
    code=subprocess.call(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
stop.set()
monitor_thread.join()
pynvml.nvmlShutdown()
(out/'exit.json').write_text(json.dumps({'exit_code':code,'start_unix':start,'end_unix':time.time()}))
print(a.name,'EXIT',code,flush=True)
sys.exit(code)
